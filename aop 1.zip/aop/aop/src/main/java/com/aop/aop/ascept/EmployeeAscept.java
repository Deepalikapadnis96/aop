package com.aop.aop.ascept;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
//ascept is a class level,method is a advice and execution is poincut and in poincut evalute to somthing is called jointpoint

import com.aop.aop.entity.Employee;

@Aspect
@Component
public class EmployeeAscept {
//controller layer logging
	@Before(value = "execution(* com.aop.aop.controller.EmployeeController.*(..))")
	public void beforeAdvice(JoinPoint joinpoint) {
		System.out.println("request To:: " + joinpoint.getSignature() + " start at " + new Date());
	}

	@After(value = "execution(* com.aop.aop.controller.EmployeeController.*(..))")
	public void afterAdvice(JoinPoint joinpoint) {
		System.out.println("request To:: " + joinpoint.getSignature() + " start at " + new Date());
	}
//service logging

	@Before(value = "execution(* com.aop.aop.service.EmployeeService.*(..))")
	public void beforeAdviceServcie(JoinPoint joinpoint) {
		System.out.println("request To service layer before:: " + joinpoint.getSignature() + " start at " + new Date());
	}

	@After(value = "execution(* com.aop.aop.service.EmployeeService.*(..))")
	public void afterAdviceService(JoinPoint joinpoint) {
		System.out.println("request To service layer after:: " + joinpoint.getSignature() + " start at " + new Date());
	}

	@AfterReturning(value = "execution(* com.aop.aop.service.EmployeeService.saveAllEmp(..))", returning = "employee")
	public void afterReturningAdvice(JoinPoint joinPoint, Employee employee) {
		System.out.println("save employee is successful>> " + employee.getId());
	}

	@AfterThrowing(value = "execution(* com.aop.aop.service.EmployeeService.saveAllEmp(..))", throwing = "exception")
	public void afterThrowingAdvice(JoinPoint joinPoint, Exception exception) {
		System.out.println("exception thorw during save method executed>> " + exception.getMessage());
	}
//if we do return type void the user cant see anythng in output 
	//if we return somthing it will shoe somthng
	@Around(value = "execution(* com.aop.aop.service.EmployeeService.saveAllEmp(..))")
	public Employee afterThrowingAdvice(ProceedingJoinPoint proceedingJoinPoint) {
		System.out.println("Inside the round the save method started>> " + new Date());

		try {
			Employee[] empArr = new Employee[1];
			Employee emp = new Employee();
			emp.setName("emp1");
			empArr[0]=emp;
			Employee employee = (Employee)proceedingJoinPoint.proceed(empArr);
			System.out.println("proceed " + employee);
			return employee;
		} catch (Throwable e) {
			System.out.println("into the catch block>>" + e.getMessage());
			// TODO: handle exception
		}
		return null;
	}
}
