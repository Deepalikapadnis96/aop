package com.aop.aop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aop.aop.entity.Employee;
import com.aop.aop.repo.EmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepo employeeRepo;

	public List<Employee> findAllEmp() {
		return employeeRepo.findAll();

	}
	

	public Employee saveAllEmp(Employee employee) throws Exception {
		if(employee.getName().length()>6) {
			throw new Exception("length is greater then 6");
		}
		return employeeRepo.save(employee);

	}
	
	
	
}
